package com.yayawan.impl;


import android.app.Application;

public class YYApplication extends Application {

	/**
	 * 乐视游戏中心的AppKey
	 */
	private static final String LETV_GAME_CENTER_APPKEY = "0e1ad337a065485f809db4105594e6d8";

	@Override
	public void onCreate() {
		super.onCreate();
	}
}
