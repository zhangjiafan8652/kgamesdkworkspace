package com.yayawan.impl;

public class Myconstant {

	public static boolean ISINIT=false;
}
