package com.kkgame.utils;

public class UrlConstants {

	public static String baseurl="https://gameapi.weisuiyu.com/";

	
	public static String active=baseurl="data/active_handler/";//激活回调
	
	
}
