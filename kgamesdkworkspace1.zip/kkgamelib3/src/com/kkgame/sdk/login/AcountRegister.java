package com.kkgame.sdk.login;

import java.util.UUID;
import java.util.zip.CRC32;

import android.app.Activity;

import com.kkgame.sdk.bean.User;
import com.kkgame.sdk.utils.CryptoUtil;
import com.kkgame.sdk.utils.Utilsjf;

public class AcountRegister {

	private String mName;
	private String mPassword;

	private User mUser;

	private Activity mActivity;

	public AcountRegister(Activity activity) {
		mActivity = activity;
	}

	private static final int REGISTER = 3;

	private static final int FETCHSMS = 4;

	protected static final int ERROR = 5;

	private void startlogin() {

		//
		Login_ho_dialog login_ho_dialog = new Login_ho_dialog(mActivity);
		login_ho_dialog.dialogShow();

	}

	public void acountRregister() {
		UUID uuid = UUID.randomUUID();
		CRC32 crc32 = new CRC32();
		crc32.update(uuid.toString().getBytes());
		mName = "yy" + crc32.getValue();
		mPassword = CryptoUtil.getSeed();
		// mPassword="123456";

		Utilsjf.creDialogpro(mActivity, "正在注册...");

	}
}
