package com.kkgame.sdk.utils;

/**
 * 检查丫丫玩方法是否完全调用的工具类
 * @author Administrator
 *
 */
public class JfdebugUtils {

}
