package com.kkgame.sdk.utils;

public abstract class TextOnClickListener {

	
		public  abstract void onclick();
	
}
