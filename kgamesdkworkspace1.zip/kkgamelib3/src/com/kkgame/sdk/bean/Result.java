package com.kkgame.sdk.bean;

public class Result {
    
    public int success;
    public String body;
    @Override
    public String toString() {
        return "Result [success=" + success + ", body=" + body + "]";
    }
    
    
}
