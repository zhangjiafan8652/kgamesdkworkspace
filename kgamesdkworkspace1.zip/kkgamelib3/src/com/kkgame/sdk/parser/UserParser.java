package com.kkgame.sdk.parser;

import org.json.JSONException;
import org.json.JSONObject;

import android.widget.Toast;

import com.kkgame.sdk.bean.User;

public class UserParser {

	

}
