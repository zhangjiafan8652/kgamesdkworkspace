package com.yayawan.proxy;

import android.app.Activity;

public interface YYWAnimation {

    public abstract void anim(Activity paramActivity);

}
