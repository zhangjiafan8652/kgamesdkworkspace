package com.yayawan.impl;


import android.app.Application;

public class YYApplication extends Application {

	

	@Override
	public void onCreate() {
		super.onCreate();
		YaYawanconstants.applicationInit(getApplicationContext());
	}
}
