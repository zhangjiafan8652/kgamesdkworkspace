package com.yayawan.impl;

/**
 * Created by liruchun on 2016/9/13.
 */

public class AppConfig {
    public static int APP_ID = 747617;
    public static String APP_KEY = "55031b9335d5402e9735a57ad26d58ec";
    public static String APP_SECRET = "7457d6899ee146d8b42aab5392e01990";
}
